<?php
// ACQUISITION_RECOMMENDATION (MOD14): purchase suggestions from alignment gaps.
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian']);
$GLOBALS['base'] = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'generate') {
        $latest = $pdo->query("SELECT MAX(generated_date) FROM alignment_analytics")->fetchColumn();
        if (!$latest) { flash('err', 'Run the alignment analytics first.'); redirect('recommendations.php'); }
        $gaps = $pdo->prepare("SELECT DISTINCT a.curriculum_subject_id, a.coverage_status, a.titles_available, s.descriptive_title, p.program_code, cu.effective_sy, cs.year_level, cs.semester
                               FROM alignment_analytics a
                               JOIN curriculum_subject cs USING(curriculum_subject_id) JOIN curriculum cu USING(curriculum_id)
                               JOIN program p USING(program_id) JOIN subject s USING(subject_id)
                               WHERE a.generated_date=? AND a.coverage_status IN ('None','Partial')");
        $gaps->execute([$latest]);
        $exists = $pdo->prepare("SELECT 1 FROM acquisition_recommendation WHERE curriculum_subject_id=? AND status IN ('Open','Ordered')");
        $ins = $pdo->prepare("INSERT INTO acquisition_recommendation (curriculum_subject_id, recommended_title, justification, priority, status, date_generated) VALUES (?,?,?,?, 'Open', CURDATE())");
        $made = 0;
        foreach ($gaps as $g) {
            $exists->execute([$g['curriculum_subject_id']]);
            if ($exists->fetch()) continue;
            $pri = $g['coverage_status'] === 'None' ? 'High' : 'Medium';
            $why = "{$g['program_code']} {$g['effective_sy']}, Year {$g['year_level']} {$g['semester']} sem: only {$g['titles_available']} of " . REQUIRED_TITLES . " required titles support this subject.";
            $ins->execute([$g['curriculum_subject_id'], 'Textbook / reference for ' . $g['descriptive_title'], $why, $pri]);
            $made++;
        }
        flash('ok', $made ? "$made new recommendation(s) generated." : 'No new gaps found; existing recommendations already cover them.');
    } elseif ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? ''; $pri = $_POST['priority'] ?? '';
        $t = trim($_POST['recommended_title'] ?? '');
        if (!in_array($status, ['Open','Ordered','Done'], true) || !in_array($pri, ['High','Medium','Low'], true) || $t === '' || mb_strlen($t) > 150)
            flash('err', 'Enter a title (max 150 chars) and valid status/priority.');
        else {
            $pdo->prepare("UPDATE acquisition_recommendation SET recommended_title=?, priority=?, status=? WHERE recommendation_id=?")->execute([$t, $pri, $status, $id]);
            flash('ok', 'Recommendation updated.');
        }
    }
    redirect('recommendations.php');
}

$rows = $pdo->query("SELECT r.*, s.subject_code, p.program_code
                     FROM acquisition_recommendation r JOIN curriculum_subject cs USING(curriculum_subject_id)
                     JOIN subject s USING(subject_id) JOIN curriculum cu USING(curriculum_id) JOIN program p USING(program_id)
                     ORDER BY FIELD(r.status,'Open','Ordered','Done'), FIELD(r.priority,'High','Medium','Low'), r.recommendation_id")->fetchAll();
$pc = ['High' => 'tag-bad', 'Medium' => 'tag-warn', 'Low' => ''];
$title = 'Acquisition Recommendations'; $active = 'admin'; $page = 'recs'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<div class="toolbar">
    <h2>Acquisition Recommendations</h2>
    <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="generate"><button class="btn btn-primary">Generate from latest analysis</button></form>
</div>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Subject</th><th>Recommended title</th><th>Justification</th><th>Priority</th><th>Status</th><th>Date</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
        <tr>
        <form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="hidden" name="id" value="<?= $r['recommendation_id'] ?>">
            <td><?= e($r['program_code']) ?><br><small><?= e($r['subject_code']) ?></small></td>
            <td><input type="text" name="recommended_title" value="<?= e($r['recommended_title']) ?>" maxlength="150" style="width:100%;min-width:220px;padding:4px"></td>
            <td><small><?= e($r['justification']) ?></small></td>
            <td><select name="priority"><?php foreach (['High','Medium','Low'] as $o): ?><option <?= $r['priority'] === $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach; ?></select></td>
            <td><select name="status"><?php foreach (['Open','Ordered','Done'] as $o): ?><option <?= $r['status'] === $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach; ?></select></td>
            <td><?= e($r['date_generated']) ?></td>
            <td><button class="btn btn-primary btn-sm">Save</button></td>
        </form>
        </tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="7">No recommendations yet. Run the analytics, then generate.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php include '../includes/footer.php'; ?>
