<?php
// Borrow / return desk (BORROW_TRANSACTION, MOD10).
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian','Staff']);
$GLOBALS['base'] = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    try {
        $pdo->beginTransaction();
        if ($action === 'borrow') {
            $no = trim($_POST['student_no'] ?? ''); $acc = trim($_POST['accession_no'] ?? '');
            $s = $pdo->prepare("SELECT student_id, status FROM student WHERE student_no=?"); $s->execute([$no]); $stu = $s->fetch();
            $b = $pdo->prepare("SELECT book_id, copies_available, status FROM book WHERE accession_no=? FOR UPDATE"); $b->execute([$acc]); $book = $b->fetch();
            if (!$stu)                         throw new RuntimeException('Student number not found.');
            if ($stu['status'] !== 'A')        throw new RuntimeException('Inactive students cannot borrow.');
            if (!$book)                        throw new RuntimeException('Accession number not found.');
            if ($book['status'] !== 'A')       throw new RuntimeException('This title has been weeded from the collection.');
            if ($book['copies_available'] < 1) throw new RuntimeException('No copies available. The student may reserve this title in the OPAC.');
            if (unpaid_fine_total($pdo, (int)$stu['student_id']) > 0) throw new RuntimeException('Student has an unpaid fine and is not eligible to borrow.');
            $dup = $pdo->prepare("SELECT 1 FROM borrow_transaction WHERE student_id=? AND book_id=? AND status IN ('B','O')");
            $dup->execute([$stu['student_id'], $book['book_id']]);
            if ($dup->fetch()) throw new RuntimeException('Student already has this title on loan.');

            $pdo->prepare("INSERT INTO borrow_transaction (student_id, book_id, borrow_date, due_date, status, processed_by)
                           VALUES (?,?,CURDATE(),DATE_ADD(CURDATE(), INTERVAL " . LOAN_DAYS . " DAY),'B',?)")
                ->execute([$stu['student_id'], $book['book_id'], $user['user_id']]);
            $pdo->prepare("UPDATE book SET copies_available = copies_available - 1 WHERE book_id=?")->execute([$book['book_id']]);
            // The student's own pending/approved reservation for this title is fulfilled.
            $pdo->prepare("UPDATE reservation SET status='C' WHERE student_id=? AND book_id=? AND status IN ('P','A')")->execute([$stu['student_id'], $book['book_id']]);
            flash('ok', 'Book issued. Due in ' . LOAN_DAYS . ' days.');
        } elseif ($action === 'return') {
            $tid = (int)($_POST['transaction_id'] ?? 0);
            $t = $pdo->prepare("SELECT * FROM borrow_transaction WHERE transaction_id=? AND status IN ('B','O') FOR UPDATE"); $t->execute([$tid]); $tx = $t->fetch();
            if (!$tx) throw new RuntimeException('Open transaction not found.');
            $late = (int)$pdo->query("SELECT GREATEST(DATEDIFF(CURDATE(), '{$tx['due_date']}'),0)")->fetchColumn();
            $fine = min(round($late * FINE_PER_DAY, 2), 999.99);
            $pdo->prepare("UPDATE borrow_transaction SET return_date=CURDATE(), status='R', fine_amount=? WHERE transaction_id=?")->execute([$fine, $tid]);
            $pdo->prepare("UPDATE book SET copies_available = LEAST(copies_available + 1, copies_total) WHERE book_id=?")->execute([$tx['book_id']]);
            if ($fine > 0) $pdo->prepare("INSERT INTO fine (transaction_id, amount) VALUES (?,?)")->execute([$tid, $fine]);

            // Notify the oldest pending reservation for this title.
            $r = $pdo->prepare("SELECT reservation_id FROM reservation WHERE book_id=? AND status='P' ORDER BY request_date, reservation_id LIMIT 1");
            $r->execute([$tx['book_id']]);
            if ($rid = $r->fetchColumn())
                $pdo->prepare("UPDATE reservation SET status='A', notified='Y', pickup_deadline=DATE_ADD(CURDATE(), INTERVAL " . PICKUP_DAYS . " DAY) WHERE reservation_id=?")->execute([$rid]);
            flash('ok', $fine > 0 ? "Returned $late day(s) late. Fine of ₱" . number_format($fine, 2) . ' recorded.' : 'Book returned on time.');
        }
        $pdo->commit();
    } catch (RuntimeException $ex) {
        $pdo->rollBack(); flash('err', $ex->getMessage());
    } catch (PDOException $ex) {
        $pdo->rollBack(); flash('err', 'Database error: ' . $ex->getMessage());
    }
    redirect('circulation.php');
}

housekeeping($pdo);
$open = $pdo->query("SELECT t.*, s.student_no, CONCAT(s.last_name, ', ', s.first_name) AS student, b.accession_no, b.title
                     FROM borrow_transaction t JOIN student s USING(student_id) JOIN book b USING(book_id)
                     WHERE t.status IN ('B','O') ORDER BY t.due_date")->fetchAll();
$recent = $pdo->query("SELECT t.*, s.student_no, b.title FROM borrow_transaction t JOIN student s USING(student_id) JOIN book b USING(book_id)
                       WHERE t.status='R' ORDER BY t.return_date DESC, t.transaction_id DESC LIMIT 10")->fetchAll();

$title = 'Circulation'; $active = 'admin'; $page = 'circ'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<section class="admin-panel">
    <h3>Issue a book</h3>
    <form method="POST" class="admin-form" style="margin-top:12px">
        <?= csrf_field() ?><input type="hidden" name="action" value="borrow">
        <div class="form-grid">
            <div class="input-group"><label>Student no. *</label><input type="text" name="student_no" placeholder="2024-00001" required></div>
            <div class="input-group"><label>Book accession no. *</label><input type="text" name="accession_no" placeholder="ACC-0001" required></div>
        </div>
        <button class="btn btn-primary">Issue (due in <?= LOAN_DAYS ?> days)</button>
    </form>
</section>

<h2 style="margin:24px 0 10px">Books on loan (<?= count($open) ?>)</h2>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Student</th><th>Book</th><th>Borrowed</th><th>Due</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($open as $t): ?>
        <tr>
            <td><?= e($t['student']) ?><br><small><?= e($t['student_no']) ?></small></td>
            <td><?= e($t['title']) ?><br><small><?= e($t['accession_no']) ?></small></td>
            <td><?= e($t['borrow_date']) ?></td><td><?= e($t['due_date']) ?></td>
            <td><span class="tag <?= $t['status'] === 'O' ? 'tag-bad' : 'tag-good' ?>"><?= $t['status'] === 'O' ? 'Overdue' : 'Borrowed' ?></span></td>
            <td><form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="return"><input type="hidden" name="transaction_id" value="<?= $t['transaction_id'] ?>"><button class="btn btn-primary btn-sm">Return</button></form></td>
        </tr>
    <?php endforeach; if (!$open): ?><tr><td colspan="6">No books on loan.</td></tr><?php endif; ?>
    </tbody>
</table></div>

<h2 style="margin:24px 0 10px">Recent returns</h2>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Student no.</th><th>Book</th><th>Returned</th><th>Fine</th></tr></thead>
    <tbody>
    <?php foreach ($recent as $t): ?>
        <tr><td><?= e($t['student_no']) ?></td><td><?= e($t['title']) ?></td><td><?= e($t['return_date']) ?></td><td>₱<?= number_format((float)$t['fine_amount'], 2) ?></td></tr>
    <?php endforeach; if (!$recent): ?><tr><td colspan="4">No returns yet.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php include '../includes/footer.php'; ?>
