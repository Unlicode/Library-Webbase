<?php
// Staff portal sub-navigation. Expects $user and $page.
$links = [
  ['index.php', 'Dashboard', 'dash', ['Admin','Librarian','Staff']],
  ['circulation.php', 'Circulation', 'circ', ['Admin','Librarian','Staff']],
  ['fines.php', 'Fines', 'fines', ['Admin','Librarian','Staff']],
  ['reservations.php', 'Reservations', 'res', ['Admin','Librarian','Staff']],
  ['manage.php?e=student', 'Students', 'student', ['Admin','Librarian','Staff']],
  ['manage.php?e=book', 'Books', 'book', ['Admin','Librarian']],
  ['manage.php?e=category', 'Categories', 'category', ['Admin','Librarian']],
  ['manage.php?e=faculty', 'Faculty', 'faculty', ['Admin','Librarian']],
  ['manage.php?e=program', 'Programs', 'program', ['Admin','Librarian']],
  ['manage.php?e=curriculum', 'Curricula', 'curriculum', ['Admin','Librarian']],
  ['manage.php?e=subject', 'Subjects', 'subject', ['Admin','Librarian']],
  ['manage.php?e=curriculum_subject', 'Curriculum Subjects', 'curriculum_subject', ['Admin','Librarian']],
  ['analytics.php', 'Alignment Analytics', 'analytics', ['Admin','Librarian']],
  ['recommendations.php', 'Acquisitions', 'recs', ['Admin','Librarian']],
  ['manage.php?e=users', 'Users', 'users', ['Admin']],
];
echo '<nav class="admin-nav">';
foreach ($links as [$href, $label, $key, $roles])
    if (in_array($user['role'], $roles, true))
        echo '<a href="' . $href . '" class="' . ($page === $key ? 'active' : '') . '">' . $label . '</a>';
echo '</nav>';
