<?php
// RESERVATION (MOD12): approve (notify) or cancel reservations.
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian','Staff']);
$GLOBALS['base'] = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $rid = (int)($_POST['reservation_id'] ?? 0);
    if (($_POST['action'] ?? '') === 'approve') {
        $u = $pdo->prepare("UPDATE reservation r JOIN book b USING(book_id)
                            SET r.status='A', r.notified='Y', r.pickup_deadline=DATE_ADD(CURDATE(), INTERVAL " . PICKUP_DAYS . " DAY)
                            WHERE r.reservation_id=? AND r.status='P' AND b.copies_available > 0");
        $u->execute([$rid]);
        flash($u->rowCount() ? 'ok' : 'err', $u->rowCount() ? 'Approved. Student notified; pickup within ' . PICKUP_DAYS . ' days.' : 'Can only approve a pending reservation while a copy is on the shelf.');
    } else {
        $pdo->prepare("UPDATE reservation SET status='C' WHERE reservation_id=? AND status IN ('P','A')")->execute([$rid]);
        flash('ok', 'Reservation cancelled.');
    }
    redirect('reservations.php');
}

housekeeping($pdo);
$rows = $pdo->query("SELECT r.*, s.student_no, CONCAT(s.last_name, ', ', s.first_name) AS student, b.title, b.copies_available
                     FROM reservation r JOIN student s USING(student_id) JOIN book b USING(book_id)
                     ORDER BY FIELD(r.status,'P','A','C'), r.request_date, r.reservation_id")->fetchAll();
$label = ['P' => ['Pending', 'tag-warn'], 'A' => ['Approved', 'tag-good'], 'C' => ['Cancelled', '']];
$title = 'Reservations'; $active = 'admin'; $page = 'res'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<h2 style="margin:10px 0">Reservations</h2>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Student</th><th>Title</th><th>Requested</th><th>Status</th><th>Pickup by</th><th>Notified</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): [$txt, $cls] = $label[$r['status']]; ?>
        <tr>
            <td><?= e($r['student']) ?><br><small><?= e($r['student_no']) ?></small></td>
            <td><?= e($r['title']) ?><br><small><?= (int)$r['copies_available'] ?> on shelf</small></td>
            <td><?= e($r['request_date']) ?></td>
            <td><span class="tag <?= $cls ?>"><?= $txt ?></span></td>
            <td><?= e($r['pickup_deadline'] ?: '-') ?></td><td><?= $r['notified'] === 'Y' ? 'Yes' : 'No' ?></td>
            <td>
            <?php if ($r['status'] !== 'C'): ?>
                <form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="reservation_id" value="<?= $r['reservation_id'] ?>">
                    <?php if ($r['status'] === 'P'): ?><button name="action" value="approve" class="btn btn-primary btn-sm">Approve</button><?php endif; ?>
                    <button name="action" value="cancel" class="btn btn-secondary btn-sm">Cancel</button></form>
            <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="7">No reservations.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php include '../includes/footer.php'; ?>
