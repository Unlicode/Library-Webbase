<?php
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian','Staff']);
$GLOBALS['base'] = '../';
housekeeping($pdo);

$n = fn(string $sql) => (int)$pdo->query($sql)->fetchColumn();
$stats = [
  'Active titles'      => $n("SELECT COUNT(*) FROM book WHERE status='A'"),
  'Copies on shelf'    => $n("SELECT COALESCE(SUM(copies_available),0) FROM book WHERE status='A'"),
  'Books on loan'      => $n("SELECT COUNT(*) FROM borrow_transaction WHERE status IN ('B','O')"),
  'Overdue'            => $n("SELECT COUNT(*) FROM borrow_transaction WHERE status='O'"),
  'Unpaid fines'       => $n("SELECT COUNT(*) FROM fine WHERE status='U'"),
  'Pending reservations' => $n("SELECT COUNT(*) FROM reservation WHERE status='P'"),
  'Active students'    => $n("SELECT COUNT(*) FROM student WHERE status='A'"),
  'Open acquisitions'  => $n("SELECT COUNT(*) FROM acquisition_recommendation WHERE status='Open'"),
];
$title = 'Staff Portal'; $active = 'admin'; $page = 'dash'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<h2>Welcome, <?= e($user['full_name']) ?> <small style="color:#64748b">(<?= e($user['role']) ?>)</small></h2>
<div class="stat-grid">
<?php foreach ($stats as $label => $v): ?><div class="stat"><b><?= $v ?></b><?= e($label) ?></div><?php endforeach; ?>
</div>
<?php include '../includes/footer.php'; ?>
