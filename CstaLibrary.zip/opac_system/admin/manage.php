<?php
// Generic CRUD screen for every master table, driven by includes/entities.php.
require_once '../includes/bootstrap.php';
require_once '../includes/entities.php';
$GLOBALS['base'] = '../';

$key = $_GET['e'] ?? '';
if (!isset($ENTITIES[$key])) { http_response_code(404); die('Unknown table.'); }
$E = $ENTITIES[$key];
$user = require_role($E['roles']);
$pk = $E['pk']; $tbl = $E['table'];

function field_value(array $f, string $name, string $raw): array {
    // returns [value, error]
    $raw = trim($raw); $label = $f[0]; $type = $f[1];
    if ($raw === '') return !empty($f['req']) ? [null, "$label is required."] : [null, null];
    if (isset($f['max']) && $type === 'text' && mb_strlen($raw) > $f['max']) return [null, "$label is too long (max {$f['max']})."];
    if ($type === 'int') {
        if (!preg_match('/^-?\d+$/', $raw)) return [null, "$label must be a whole number."];
        $v = (int)$raw;
        if (isset($f['min']) && $v < $f['min']) return [null, "$label must be at least {$f['min']}."];
        $mx = isset($f['maxfn']) ? (int)date('Y') : ($f['max'] ?? null);
        if ($mx !== null && $v > $mx) return [null, "$label must not exceed $mx."];
        return [$v, null];
    }
    if (isset($f['pattern']) && !preg_match($f['pattern'], $raw)) return [null, $f['patmsg'] ?? "$label has an invalid format."];
    if (isset($f['options']) && !isset($f['options'][$raw])) return [null, "$label has an invalid choice."];
    return [$raw, null];
}

$id = (int)($_GET['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? 'save';
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'delete' && $id) {
        try {
            $pdo->prepare("DELETE FROM `$tbl` WHERE `$pk` = ?")->execute([$id]);
            flash('ok', 'Record deleted.');
        } catch (PDOException $ex) {
            flash('err', 'Cannot delete: other records still depend on it (ON DELETE RESTRICT). Set it to Inactive/Weeded instead if applicable.');
        }
        redirect("manage.php?e=$key");
    }

    $data = []; $errors = [];
    foreach ($E['fields'] as $name => $f) {
        [$v, $err] = field_value($f, $name, (string)($_POST[$name] ?? ''));
        if ($err) $errors[] = $err;
        $data[$name] = $v;
    }
    if (!empty($E['password'])) {
        $pw = $_POST['password'] ?? '';
        if ($pw !== '' || !$id) {
            if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,}$/', $pw)) $errors[] = 'Password needs at least 8 characters with 1 letter and 1 digit.';
        }
    }
    if (!$errors && isset($E['validate']) && ($m = $E['validate']($data))) $errors[] = $m;

    if ($errors) {
        foreach ($errors as $m) flash('err', $m);
        $_SESSION['old'] = $_POST;
        redirect("manage.php?e=$key" . ($id ? "&id=$id" : '') . '&form=1');
    }

    try {
        $pdo->beginTransaction();
        if (!empty($E['account']) && !$id) {
            // Create the linked login account first (STUDENT/FACULTY.user_id is NOT NULL).
            $no = $data[$E['account']['no_field']];
            $name = trim(($data['first_name'] ?? '') . ' ' . ($data['last_name'] ?? ''));
            $pdo->prepare("INSERT INTO users (username, password_hash, role, full_name, status) VALUES (?,?,?,?,?)")
                ->execute([$no, password_hash($no, PASSWORD_BCRYPT), $E['account']['role'], $name, $data['status']]);
            $data['user_id'] = (int)$pdo->lastInsertId();
        }
        if ($id) {
            $set = implode(',', array_map(fn($c) => "`$c` = :$c", array_keys($data)));
            $pdo->prepare("UPDATE `$tbl` SET $set WHERE `$pk` = :__id")->execute($data + ['__id' => $id]);
            if (!empty($E['account'])) {
                $pdo->prepare("UPDATE users SET status=?, full_name=? WHERE user_id=(SELECT user_id FROM `$tbl` WHERE `$pk`=?)")
                    ->execute([$data['status'], trim($data['first_name'] . ' ' . $data['last_name']), $id]);
            }
        } else {
            $cols = implode(',', array_map(fn($c) => "`$c`", array_keys($data)));
            $ph = implode(',', array_map(fn($c) => ":$c", array_keys($data)));
            if (!empty($E['password'])) { $cols .= ',`password_hash`'; $ph .= ',:__pw'; $data['__pw'] = password_hash($_POST['password'], PASSWORD_BCRYPT); }
            $pdo->prepare("INSERT INTO `$tbl` ($cols) VALUES ($ph)")->execute($data);
            $id = (int)$pdo->lastInsertId();
        }
        if (!empty($E['password']) && $id && ($_POST['password'] ?? '') !== '' && isset($_POST['id']) && $_POST['id']) {
            $pdo->prepare("UPDATE users SET password_hash=? WHERE user_id=?")->execute([password_hash($_POST['password'], PASSWORD_BCRYPT), $id]);
        }
        if (isset($E['after_save'])) $E['after_save']($pdo, $id);
        $pdo->commit();
        flash('ok', 'Record saved.');
    } catch (PDOException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $dup = $ex->errorInfo[1] ?? 0;
        flash('err', $dup == 1062 ? 'Duplicate value: a unique field (code, number, ISBN, username...) already exists.'
                    : ($dup == 3819 ? 'A validation rule (CHECK constraint) rejected the values.' : 'Database error: ' . $ex->getMessage()));
        $_SESSION['old'] = $_POST;
        redirect("manage.php?e=$key" . ($id ? "&id=$id" : '') . '&form=1');
    }
    redirect("manage.php?e=$key");
}

housekeeping($pdo);
$showForm = isset($_GET['form']) || $id;
$edit = [];
if ($id) {
    $s = $pdo->prepare("SELECT * FROM `$tbl` WHERE `$pk` = ?"); $s->execute([$id]); $edit = $s->fetch() ?: [];
}
if (!empty($_SESSION['old'])) { $edit = $_SESSION['old'] + $edit; unset($_SESSION['old']); }
$rows = $pdo->query($E['list'])->fetchAll();

$title = $E['label']; $active = 'admin'; $page = $key; $base = '../';
include '../includes/header.php';
include '_nav.php';
?>
<div class="toolbar">
    <h2><?= e($E['label']) ?> (<?= count($rows) ?>)</h2>
    <?php if (!$showForm): ?><a class="btn btn-primary" href="manage.php?e=<?= e($key) ?>&form=1">+ Add new</a><?php endif; ?>
</div>

<?php if ($showForm): ?>
<section class="admin-panel">
    <h3><?= $id ? 'Edit' : 'Add' ?> record</h3>
    <form method="POST" class="admin-form" style="margin-top:12px">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
        <div class="form-grid">
        <?php foreach ($E['fields'] as $name => $f):
            $val = $edit[$name] ?? ($f['default'] ?? '');
            $locked = $id && !empty($E['account']) && $name === $E['account']['no_field']; ?>
            <div class="input-group">
                <label><?= e($f[0]) ?><?= !empty($f['req']) ? ' *' : '' ?></label>
                <?php if ($f[1] === 'select'):
                    $opts = $f['options'] ?? [];
                    if (isset($f['lookup'])) foreach ($pdo->query($f['lookup'])->fetchAll(PDO::FETCH_NUM) as [$k, $v]) $opts[$k] = $v; ?>
                    <select name="<?= e($name) ?>">
                        <option value="">-- select --</option>
                        <?php foreach ($opts as $k => $v): ?>
                            <option value="<?= e($k) ?>" <?= (string)$val === (string)$k ? 'selected' : '' ?>><?= e($v) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input type="<?= $f[1] === 'int' ? 'number' : 'text' ?>" name="<?= e($name) ?>" value="<?= e($val) ?>" <?= $locked ? 'readonly' : '' ?>>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php if (!empty($E['password'])): ?>
            <div class="input-group"><label>Password <?= $id ? '(leave blank to keep)' : '*' ?></label><input type="password" name="password" autocomplete="new-password"></div>
        <?php endif; ?>
        </div>
        <?php if (!empty($E['account']) && !$id): ?>
            <p style="font-size:.85rem;color:#64748b;margin:8px 0">A login account is created automatically; its username and initial password are the <?= e($E['account']['no_field'] === 'student_no' ? 'student' : 'employee') ?> number.</p>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="manage.php?e=<?= e($key) ?>" class="btn btn-secondary">Cancel</a>
    </form>
</section>
<?php endif; ?>

<div class="table-wrap">
<table class="data">
    <thead><tr><?php foreach ($E['cols'] as $label): ?><th><?= e($label) ?></th><?php endforeach; ?><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
        <tr>
            <?php foreach ($E['cols'] as $c => $label): $v = $r[$c] ?? '';
                if ($c === 'status') $v = ['A' => 'Active', 'I' => 'Inactive', 'W' => 'Weeded'][$v] ?? $v; ?>
                <td><?= e($v) ?></td>
            <?php endforeach; ?>
            <td>
                <a class="btn btn-outline btn-sm" href="manage.php?e=<?= e($key) ?>&id=<?= $r[$pk] ?>">Edit</a>
                <form method="POST" class="inline-form" onsubmit="return confirm('Delete this record?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r[$pk] ?>">
                    <button class="btn btn-secondary btn-sm">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="<?= count($E['cols']) + 1 ?>">No records yet.</td></tr><?php endif; ?>
    </tbody>
</table>
</div>
<?php include '../includes/footer.php'; ?>
