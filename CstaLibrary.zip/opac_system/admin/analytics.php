<?php
// ALIGNMENT_ANALYTICS (MOD13): compares the collection against subjects of every Active curriculum.
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian']);
$GLOBALS['base'] = '../';

const MATCH_MIN  = 0.25;  // minimum keyword overlap for a book to count as supporting a subject
const TOP_MATCHES = 5;    // matching books stored per subject

function tokens(string $s): array {
    static $stop = ['the','and','for','with','from','into','that','this','its','are','introduction','intro','fundamentals','basic','basics','concepts','principles','studies','study','using','use','their','our','your','philippine','world','general'];
    $out = [];
    foreach (preg_split('/[^a-z0-9]+/', strtolower($s), -1, PREG_SPLIT_NO_EMPTY) as $w) {
        if (strlen($w) < 3 || in_array($w, $stop, true)) continue;
        if (strlen($w) > 4 && str_ends_with($w, 's')) $w = substr($w, 0, -1);   // crude plural stemming
        $out[$w] = true;
    }
    return array_keys($out);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $books = $pdo->query("SELECT b.book_id, b.title, b.author, c.category_name FROM book b JOIN book_category c USING(category_id) WHERE b.status='A'")->fetchAll();
        if (!$books) throw new RuntimeException('Add books to the catalog before running the analytics.');
        foreach ($books as &$b) $b['tok'] = tokens($b['title'] . ' ' . $b['category_name']);
        unset($b);

        $subs = $pdo->query("SELECT cs.curriculum_subject_id, s.descriptive_title, s.description
                             FROM curriculum_subject cs JOIN curriculum cu USING(curriculum_id) JOIN subject s USING(subject_id)
                             WHERE cu.status='A'")->fetchAll();
        if (!$subs) throw new RuntimeException('No subjects found in any Active curriculum.');

        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM alignment_analytics WHERE generated_date = CURDATE()");   // one run per day
        $ins = $pdo->prepare("INSERT INTO alignment_analytics (curriculum_subject_id, book_id, relevance_score, titles_available, coverage_status, remarks, generated_date)
                              VALUES (?,?,?,?,?,?,CURDATE())");
        $counts = ['Aligned' => 0, 'Partial' => 0, 'None' => 0];
        foreach ($subs as $s) {
            $st = tokens($s['descriptive_title'] . ' ' . ($s['description'] ?? ''));
            $scored = [];
            foreach ($books as $b) {
                $score = $st ? count(array_intersect($st, $b['tok'])) / count($st) : 0;
                $scored[] = ['id' => $b['book_id'], 'score' => min(1, round($score, 2))];
            }
            usort($scored, fn($x, $y) => $y['score'] <=> $x['score']);
            $matches = array_values(array_filter($scored, fn($m) => $m['score'] >= MATCH_MIN));
            $n = count($matches);
            $cov = $n >= REQUIRED_TITLES ? 'Aligned' : ($n >= 1 ? 'Partial' : 'None');
            $counts[$cov]++;
            if ($n === 0) {
                $ins->execute([$s['curriculum_subject_id'], $scored[0]['id'], $scored[0]['score'], 0, 'None', 'No relevant title found; closest catalog record shown. Acquisition needed.']);
            } else {
                foreach (array_slice($matches, 0, TOP_MATCHES) as $m) {
                    $rem = $cov === 'Partial' ? 'Only ' . $n . ' of ' . REQUIRED_TITLES . ' required titles available.' : null;
                    $ins->execute([$s['curriculum_subject_id'], $m['id'], $m['score'], $n, $cov, $rem]);
                }
            }
        }
        $pdo->commit();
        flash('ok', "Analysis complete: {$counts['Aligned']} aligned, {$counts['Partial']} partial, {$counts['None']} with no coverage.");
    } catch (RuntimeException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('err', $ex->getMessage());
    }
    redirect('analytics.php');
}

$latest = $pdo->query("SELECT MAX(generated_date) FROM alignment_analytics")->fetchColumn();
$rows = [];
if ($latest) {
    $q = $pdo->prepare("SELECT p.program_code, cu.effective_sy, s.subject_code, s.descriptive_title, cs.year_level, cs.semester,
                               a.coverage_status, a.titles_available, MAX(a.relevance_score) AS best, GROUP_CONCAT(b.title ORDER BY a.relevance_score DESC SEPARATOR ' | ') AS titles, MAX(a.remarks) AS remarks
                        FROM alignment_analytics a
                        JOIN curriculum_subject cs USING(curriculum_subject_id) JOIN curriculum cu USING(curriculum_id)
                        JOIN program p USING(program_id) JOIN subject s USING(subject_id) JOIN book b ON b.book_id=a.book_id
                        WHERE a.generated_date = ?
                        GROUP BY a.curriculum_subject_id, p.program_code, cu.effective_sy, s.subject_code, s.descriptive_title, cs.year_level, cs.semester, a.coverage_status, a.titles_available
                        ORDER BY p.program_code, cs.year_level, cs.semester, s.subject_code");
    $q->execute([$latest]); $rows = $q->fetchAll();
}
$sum = ['Aligned' => 0, 'Partial' => 0, 'None' => 0];
foreach ($rows as $r) $sum[$r['coverage_status']]++;
$pct = $rows ? round($sum['Aligned'] / count($rows) * 100) : 0;
$cls = ['Aligned' => 'tag-good', 'Partial' => 'tag-warn', 'None' => 'tag-bad'];

$title = 'Alignment Analytics'; $active = 'admin'; $page = 'analytics'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<div class="toolbar">
    <h2>Curriculum-to-Collection Alignment</h2>
    <form method="POST"><?= csrf_field() ?><button class="btn btn-primary">▶ Run analysis now</button></form>
</div>
<p style="color:#64748b;margin-bottom:10px">Matches each subject of every Active curriculum against catalog titles (title and category keywords). A subject is <b>Aligned</b> with <?= REQUIRED_TITLES ?>+ matching titles, <b>Partial</b> with 1–<?= REQUIRED_TITLES - 1 ?>, and <b>None</b> with 0.</p>
<?php if ($latest): ?>
<div class="stat-grid">
    <div class="stat"><b><?= $pct ?>%</b>Subjects aligned</div>
    <div class="stat"><b><?= $sum['Aligned'] ?></b>Aligned</div>
    <div class="stat"><b><?= $sum['Partial'] ?></b>Partial</div>
    <div class="stat"><b><?= $sum['None'] ?></b>No coverage</div>
</div>
<p style="margin-bottom:10px">Last run: <b><?= e($latest) ?></b></p>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Program</th><th>Subject</th><th>Yr / Sem</th><th>Coverage</th><th>Titles</th><th>Best score</th><th>Matching books</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
        <tr>
            <td><?= e($r['program_code']) ?><br><small><?= e($r['effective_sy']) ?></small></td>
            <td><?= e($r['subject_code']) ?> — <?= e($r['descriptive_title']) ?></td>
            <td><?= (int)$r['year_level'] ?> / <?= e($r['semester']) ?></td>
            <td><span class="tag <?= $cls[$r['coverage_status']] ?>"><?= e($r['coverage_status']) ?></span></td>
            <td><?= (int)$r['titles_available'] ?></td><td><?= number_format((float)$r['best'], 2) ?></td>
            <td><?= $r['coverage_status'] === 'None' ? '<em>' . e($r['remarks']) . '</em>' : e($r['titles']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table></div>
<?php else: ?>
<div class="empty-state"><h3>No analysis yet</h3><p>Click “Run analysis now” to generate the first report.</p></div>
<?php endif; ?>
<?php include '../includes/footer.php'; ?>
