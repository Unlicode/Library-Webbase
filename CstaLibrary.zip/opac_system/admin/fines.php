<?php
// FINE (MOD11): list fines and record payment (official receipt number required).
require_once '../includes/bootstrap.php';
$user = require_role(['Admin','Librarian','Staff']);
$GLOBALS['base'] = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $fid = (int)($_POST['fine_id'] ?? 0);
    $or = trim($_POST['or_number'] ?? '');
    if (!preg_match('/^[A-Za-z0-9\-]{1,20}$/', $or)) flash('err', 'An official receipt number (letters, digits, dash; max 20) is required.');
    else {
        $u = $pdo->prepare("UPDATE fine SET status='P', date_paid=CURDATE(), or_number=? WHERE fine_id=? AND status='U'");
        $u->execute([$or, $fid]);
        flash($u->rowCount() ? 'ok' : 'err', $u->rowCount() ? 'Payment recorded. The student may borrow again.' : 'Fine not found or already paid.');
    }
    redirect('fines.php');
}

$rows = $pdo->query("SELECT f.*, t.return_date, t.due_date, s.student_no, CONCAT(s.last_name, ', ', s.first_name) AS student, b.title
                     FROM fine f JOIN borrow_transaction t USING(transaction_id) JOIN student s USING(student_id) JOIN book b USING(book_id)
                     ORDER BY f.status, f.fine_id DESC")->fetchAll();
$title = 'Fines'; $active = 'admin'; $page = 'fines'; $base = '../';
include '../includes/header.php'; include '_nav.php';
?>
<h2 style="margin:10px 0">Fines (₱<?= number_format(FINE_PER_DAY, 2) ?> per overdue day)</h2>
<div class="table-wrap"><table class="data">
    <thead><tr><th>Student</th><th>Book</th><th>Due</th><th>Returned</th><th>Amount</th><th>Status</th><th>Payment</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $f): ?>
        <tr>
            <td><?= e($f['student']) ?><br><small><?= e($f['student_no']) ?></small></td>
            <td><?= e($f['title']) ?></td><td><?= e($f['due_date']) ?></td><td><?= e($f['return_date']) ?></td>
            <td>₱<?= number_format((float)$f['amount'], 2) ?></td>
            <td><span class="tag <?= $f['status'] === 'P' ? 'tag-good' : 'tag-bad' ?>"><?= $f['status'] === 'P' ? 'Paid' : 'Unpaid' ?></span></td>
            <td>
            <?php if ($f['status'] === 'U'): ?>
                <form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="fine_id" value="<?= $f['fine_id'] ?>">
                    <input type="text" name="or_number" placeholder="OR number" required style="width:110px;padding:4px"> <button class="btn btn-primary btn-sm">Mark paid</button></form>
            <?php else: ?>OR <?= e($f['or_number']) ?> on <?= e($f['date_paid']) ?><?php endif; ?>
            </td>
        </tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="7">No fines recorded.</td></tr><?php endif; ?>
    </tbody>
</table></div>
<?php include '../includes/footer.php'; ?>
