<?php
// Entity definitions that drive admin/manage.php (one generic CRUD screen per table).
// field types: text, int, year, date, select (options list or lookup SQL), textarea
// 'pattern' = regex checked server-side (data dictionary validation rule).
$YN_AI = ['A' => 'Active', 'I' => 'Inactive'];

$ENTITIES = [
  'category' => [
    'label' => 'Book Categories', 'table' => 'book_category', 'pk' => 'category_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT * FROM book_category ORDER BY category_name",
    'cols' => ['category_name' => 'Category', 'description' => 'Description'],
    'fields' => [
      'category_name' => ['Category name', 'text', 'req' => true, 'max' => 60],
      'description'   => ['Description', 'text', 'max' => 200],
    ],
  ],
  'book' => [
    'label' => 'Books', 'table' => 'book', 'pk' => 'book_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT b.*, c.category_name FROM book b JOIN book_category c USING(category_id) ORDER BY b.title",
    'cols' => ['accession_no' => 'Accession', 'title' => 'Title', 'author' => 'Author', 'category_name' => 'Category', 'copies_available' => 'Avail', 'copies_total' => 'Total', 'status' => 'Status'],
    'fields' => [
      'accession_no'     => ['Accession no.', 'text', 'req' => true, 'max' => 15],
      'title'            => ['Title', 'text', 'req' => true, 'max' => 150],
      'author'           => ['Author', 'text', 'req' => true, 'max' => 80],
      'publisher'        => ['Publisher', 'text', 'max' => 80],
      'publication_year' => ['Publication year', 'int', 'req' => true, 'min' => 1900, 'maxfn' => 'year'],
      'isbn'             => ['ISBN (10 or 13 digits)', 'text', 'max' => 20, 'pattern' => '/^(\d{10}|\d{13})$/', 'patmsg' => 'ISBN must be 10 or 13 digits, no dashes.'],
      'category_id'      => ['Category', 'select', 'req' => true, 'lookup' => "SELECT category_id, category_name FROM book_category ORDER BY 2"],
      'copies_total'     => ['Copies owned', 'int', 'req' => true, 'min' => 1, 'max' => 999, 'default' => 1],
      'copies_available' => ['Copies on shelf', 'int', 'req' => true, 'min' => 0, 'max' => 999, 'default' => 1],
      'shelf_location'   => ['Shelf / call no.', 'text', 'max' => 20],
      'status'           => ['Status', 'select', 'req' => true, 'options' => ['A' => 'Active', 'W' => 'Weeded'], 'default' => 'A'],
    ],
    'validate' => function (array $d): ?string {
        return $d['copies_available'] > $d['copies_total'] ? 'Copies on shelf cannot exceed copies owned.' : null;
    },
  ],
  'program' => [
    'label' => 'Programs', 'table' => 'program', 'pk' => 'program_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT * FROM program ORDER BY program_code",
    'cols' => ['program_code' => 'Code', 'program_name' => 'Program', 'department' => 'Department'],
    'fields' => [
      'program_code' => ['Program code', 'text', 'req' => true, 'max' => 15],
      'program_name' => ['Program name', 'text', 'req' => true, 'max' => 100],
      'department'   => ['Department', 'text', 'req' => true, 'max' => 60],
      'description'  => ['Description', 'text', 'max' => 200],
    ],
  ],
  'curriculum' => [
    'label' => 'Curricula', 'table' => 'curriculum', 'pk' => 'curriculum_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT c.*, p.program_code FROM curriculum c JOIN program p USING(program_id) ORDER BY p.program_code, c.effective_sy DESC",
    'cols' => ['program_code' => 'Program', 'effective_sy' => 'Effective SY', 'description' => 'Description', 'approved_by' => 'Approved by', 'status' => 'Status'],
    'fields' => [
      'program_id'   => ['Program', 'select', 'req' => true, 'lookup' => "SELECT program_id, program_code FROM program ORDER BY 2"],
      'effective_sy' => ['Effective school year (YYYY-YYYY)', 'text', 'req' => true, 'max' => 9, 'pattern' => '/^\d{4}-\d{4}$/', 'patmsg' => 'Use the format YYYY-YYYY.'],
      'description'  => ['Description', 'text', 'max' => 200],
      'approved_by'  => ['Approved by', 'text', 'max' => 80],
      'status'       => ['Status', 'select', 'req' => true, 'options' => $YN_AI, 'default' => 'A'],
    ],
    'after_save' => function (PDO $pdo, int $id): void {
        // Only one Active curriculum per program.
        $row = $pdo->query("SELECT program_id, status FROM curriculum WHERE curriculum_id=$id")->fetch();
        if ($row && $row['status'] === 'A') {
            $pdo->prepare("UPDATE curriculum SET status='I' WHERE program_id=? AND curriculum_id<>?")->execute([$row['program_id'], $id]);
        }
    },
  ],
  'subject' => [
    'label' => 'Subjects', 'table' => 'subject', 'pk' => 'subject_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT * FROM subject ORDER BY subject_code",
    'cols' => ['subject_code' => 'Code', 'descriptive_title' => 'Title', 'units' => 'Units', 'description' => 'Description'],
    'fields' => [
      'subject_code'      => ['Subject code', 'text', 'req' => true, 'max' => 15],
      'descriptive_title' => ['Descriptive title', 'text', 'req' => true, 'max' => 100],
      'units'             => ['Units', 'int', 'req' => true, 'min' => 1, 'max' => 6],
      'description'       => ['Description (used for book matching)', 'text', 'max' => 200],
    ],
  ],
  'curriculum_subject' => [
    'label' => 'Curriculum Subjects', 'table' => 'curriculum_subject', 'pk' => 'curriculum_subject_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT cs.*, p.program_code, cu.effective_sy, s.subject_code, s.descriptive_title
               FROM curriculum_subject cs JOIN curriculum cu USING(curriculum_id) JOIN program p USING(program_id) JOIN subject s USING(subject_id)
               ORDER BY p.program_code, cu.effective_sy DESC, cs.year_level, cs.semester",
    'cols' => ['program_code' => 'Program', 'effective_sy' => 'SY', 'subject_code' => 'Subject', 'descriptive_title' => 'Title', 'year_level' => 'Year', 'semester' => 'Sem'],
    'fields' => [
      'curriculum_id' => ['Curriculum', 'select', 'req' => true, 'lookup' => "SELECT cu.curriculum_id, CONCAT(p.program_code,' ',cu.effective_sy) FROM curriculum cu JOIN program p USING(program_id) ORDER BY 2"],
      'subject_id'    => ['Subject', 'select', 'req' => true, 'lookup' => "SELECT subject_id, CONCAT(subject_code,' - ',descriptive_title) FROM subject ORDER BY 2"],
      'year_level'    => ['Year level', 'int', 'req' => true, 'min' => 1, 'max' => 4],
      'semester'      => ['Semester', 'select', 'req' => true, 'options' => ['1st' => '1st', '2nd' => '2nd', 'Summer' => 'Summer']],
    ],
  ],
  'student' => [
    'label' => 'Students', 'table' => 'student', 'pk' => 'student_id', 'roles' => ['Admin','Librarian','Staff'],
    'list' => "SELECT s.*, p.program_code FROM student s JOIN program p USING(program_id) ORDER BY s.last_name, s.first_name",
    'cols' => ['student_no' => 'Student No.', 'last_name' => 'Last name', 'first_name' => 'First name', 'program_code' => 'Program', 'year_level' => 'Year', 'section' => 'Section', 'status' => 'Status'],
    'fields' => [
      'student_no' => ['Student no. (YYYY-NNNNN)', 'text', 'req' => true, 'max' => 15, 'pattern' => '/^\d{4}-\d{5}$/', 'patmsg' => 'Student number must look like 2024-00001.'],
      'last_name'  => ['Last name', 'text', 'req' => true, 'max' => 40],
      'first_name' => ['First name', 'text', 'req' => true, 'max' => 40],
      'year_level' => ['Year level', 'int', 'req' => true, 'min' => 1, 'max' => 4],
      'section'    => ['Section', 'text', 'req' => true, 'max' => 10],
      'program_id' => ['Program', 'select', 'req' => true, 'lookup' => "SELECT program_id, program_code FROM program ORDER BY 2"],
      'status'     => ['Status', 'select', 'req' => true, 'options' => $YN_AI, 'default' => 'A'],
    ],
    'account' => ['no_field' => 'student_no', 'role' => 'Student'],   // auto-create linked USERS row
  ],
  'faculty' => [
    'label' => 'Faculty', 'table' => 'faculty', 'pk' => 'faculty_id', 'roles' => ['Admin','Librarian'],
    'list' => "SELECT * FROM faculty ORDER BY last_name, first_name",
    'cols' => ['employee_no' => 'Employee No.', 'last_name' => 'Last name', 'first_name' => 'First name', 'department' => 'Department', 'position' => 'Position', 'status' => 'Status'],
    'fields' => [
      'employee_no' => ['Employee no.', 'text', 'req' => true, 'max' => 15],
      'last_name'   => ['Last name', 'text', 'req' => true, 'max' => 40],
      'first_name'  => ['First name', 'text', 'req' => true, 'max' => 40],
      'department'  => ['Department', 'text', 'req' => true, 'max' => 50],
      'position'    => ['Position', 'text', 'max' => 30],
      'status'      => ['Status', 'select', 'req' => true, 'options' => $YN_AI, 'default' => 'A'],
    ],
    'account' => ['no_field' => 'employee_no', 'role' => 'Faculty'],
  ],
  'users' => [
    'label' => 'User Accounts', 'table' => 'users', 'pk' => 'user_id', 'roles' => ['Admin'],
    'list' => "SELECT user_id, username, role, full_name, status, created_at FROM users ORDER BY role, username",
    'cols' => ['username' => 'Username', 'full_name' => 'Full name', 'role' => 'Role', 'status' => 'Status', 'created_at' => 'Created'],
    'fields' => [
      'username'  => ['Username (5-20: letters, digits, _)', 'text', 'req' => true, 'max' => 20, 'pattern' => '/^[A-Za-z0-9_\-]{5,20}$/', 'patmsg' => 'Username must be 5-20 letters, digits, _ or -.'],
      'full_name' => ['Full name', 'text', 'req' => true, 'max' => 80],
      'role'      => ['Role', 'select', 'req' => true, 'options' => ['Admin' => 'Admin', 'Librarian' => 'Librarian', 'Staff' => 'Staff', 'Student' => 'Student', 'Faculty' => 'Faculty']],
      'status'    => ['Status', 'select', 'req' => true, 'options' => $YN_AI, 'default' => 'A'],
    ],
    'password' => true,
  ],
];
