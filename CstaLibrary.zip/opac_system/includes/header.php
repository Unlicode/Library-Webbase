<?php
// Expects $title and optionally $base ('' for root pages, '../' for admin pages) and $active.
$base ??= '';
$u = current_user();
$GLOBALS['base'] = $base;
$nav = [['index.php', 'Catalog Search', 'catalog']];
if ($u && in_array($u['role'], ['Admin', 'Librarian', 'Staff'], true)) $nav[] = ['admin/index.php', 'Staff Portal', 'admin'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - Smart Library OPAC</title>
    <link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>

<body>
    <header class="navbar">
        <div class="container nav-content">
            <div class="brand">
                <span class="logo-icon">📚</span>
                <div>
                    <h1>CSTA Library</h1>
                    <p class="subtitle">Online Public Access Catalog</p>
                </div>
            </div>
            <nav>
                <?php foreach ($nav as [$href, $label, $key]): ?>
                    <a href="<?= $base . $href ?>" class="<?= ($active ?? '') === $key ? 'active' : '' ?>"><?= $label ?></a>
                <?php endforeach; ?>
                <?php if ($u): ?>
                    <a href="<?= $base ?>logout.php">Logout (<?= e($u['username']) ?>)</a>
                <?php else: ?>
                    <a href="<?= $base ?>login.php" class="<?= ($active ?? '') === 'login' ? 'active' : '' ?>">Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="container">
        <?= flashes() ?>