<?php
// Shared bootstrap: session, database, helpers, auth guards.
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/db.php';

const LOAN_DAYS        = 3;     // default loan period (due_date = borrow_date + 3 days)
const FINE_PER_DAY     = 5.00;  // pesos per overdue day
const PICKUP_DAYS      = 2;     // days to claim an approved reservation
const REQUIRED_TITLES  = 3;     // titles needed for a subject to be "Aligned"

function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header("Location: $url"); exit; }
function flash(string $type, string $msg): void { $_SESSION['flash'][] = [$type, $msg]; }
function flashes(): string {
    $out = '';
    foreach ($_SESSION['flash'] ?? [] as [$t, $m]) $out .= '<div class="alert alert-' . ($t === 'ok' ? 'success' : 'error') . '">' . e($m) . '</div>';
    unset($_SESSION['flash']);
    return $out;
}
function csrf_token(): string {
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); die('Invalid form token. Go back and try again.'); }
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }

// Roles: Admin = everything; Librarian = everything except user accounts; Staff = circulation desk only.
function require_role(array $roles): array {
    $u = current_user();
    if (!$u) redirect(($GLOBALS['base'] ?? '') . 'login.php');
    if (!in_array($u['role'], $roles, true)) { http_response_code(403); die('You do not have access to this page.'); }
    return $u;
}

// Keep derived statuses current whenever a staff page loads.
function housekeeping(PDO $pdo): void {
    $pdo->exec("UPDATE borrow_transaction SET status='O' WHERE status='B' AND due_date < CURDATE()");
    $pdo->exec("UPDATE reservation SET status='C' WHERE status='A' AND pickup_deadline < CURDATE()");
}

function unpaid_fine_total(PDO $pdo, int $studentId): float {
    $s = $pdo->prepare("SELECT COALESCE(SUM(f.amount),0) FROM fine f JOIN borrow_transaction t ON t.transaction_id=f.transaction_id WHERE t.student_id=? AND f.status='U'");
    $s->execute([$studentId]);
    return (float)$s->fetchColumn();
}
