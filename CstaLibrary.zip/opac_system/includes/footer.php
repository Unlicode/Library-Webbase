</main>
<footer class="footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> Smart Library Management System &mdash; BSIT 3-3/3-4 DBSYS Project.</p>
    </div>
</footer>
</body>

</html>