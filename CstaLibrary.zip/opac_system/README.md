# Smart Library Management System with OPAC and Curriculum-to-Collection Alignment Analytics

Rebuilt from the original OPAC web system so that every table, key, validation rule and relationship
follows the ERD / data dictionary workbook (14 modules, MOD1–MOD14). Stack: HTML, CSS, JavaScript, PHP (PDO), MySQL 8.0.16+.

## Setup
1. Import `database.sql` (phpMyAdmin or `mysql < database.sql`). It creates `opac_db` with sample data.
2. Edit `config/db.php` if your MySQL credentials differ.
3. Put the folder in your web root (XAMPP `htdocs`, Laragon `www`) and open `http://localhost/opac_system/setup.php` **once** to set the demo password, then delete `setup.php`.
4. Public catalog: `index.php`. Staff portal: `login.php`.

Demo accounts (password `Password1`): `admin` (Admin), `librarian` (Librarian), `staff01` (Staff).

## Modules
| Module | Where |
|---|---|
| MOD1 USERS, MOD2 STUDENT, MOD3 FACULTY | `admin/manage.php?e=users / student / faculty` (student & faculty creation auto-creates the linked login) |
| MOD4 BOOK, MOD5 BOOK_CATEGORY | `admin/manage.php?e=book / category`; public search in `index.php` |
| MOD6 PROGRAM, MOD7 CURRICULUM, MOD8 SUBJECT, MOD9 CURRICULUM_SUBJECT | `admin/manage.php?e=...` |
| MOD10 BORROW_TRANSACTION | `admin/circulation.php` (3-day loan, stock update, fine on late return) |
| MOD11 FINE | `admin/fines.php` (OR number required to mark paid) |
| MOD12 RESERVATION | OPAC modal → `reserve.php`; staff in `admin/reservations.php` |
| MOD13 ALIGNMENT_ANALYTICS | `admin/analytics.php` |
| MOD14 ACQUISITION_RECOMMENDATION | `admin/recommendations.php` |

## Business rules implemented
- Loan period 3 days; fine ₱5.00/overdue day (constants in `includes/bootstrap.php`).
- A student with an unpaid fine cannot borrow; inactive students cannot borrow.
- `copies_available` drops on borrow, is restored on return, and can never exceed `copies_total`.
- Reservations are allowed only when no copy is on the shelf, once per student per title while pending; the oldest pending one is auto-approved (notified, 2-day pickup) when a copy returns; unclaimed approvals expire.
- Only one Active curriculum per program.
- Alignment: Aligned = 3+ matching titles, Partial = 1–2, None = 0. High-priority recommendations come from None, Medium from Partial.

## Notes / assumptions where the workbook was silent
- USERS.role allows Admin, Librarian, Staff (staff portal) plus Student and Faculty, because the STUDENT flowchart creates a 'Student' account.
- For a subject with no matching book, ALIGNMENT_ANALYTICS (book_id is required) stores the closest catalog record with score and titles 0.
- Title-matching is keyword overlap of subject title/description against book title and category.
