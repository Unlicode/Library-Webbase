<?php
require_once 'includes/bootstrap.php';

$search   = trim($_GET['search'] ?? '');
$category = (int)($_GET['category'] ?? 0);
$avail    = $_GET['availability'] ?? '';

$sql = "SELECT b.*, c.category_name,
               (SELECT COUNT(*) FROM reservation r WHERE r.book_id=b.book_id AND r.status IN ('P','A')) AS holds
        FROM book b JOIN book_category c ON c.category_id = b.category_id
        WHERE b.status = 'A'";
$p = [];
if ($search !== '') {
    $sql .= " AND (b.title LIKE :s OR b.author LIKE :s OR b.isbn LIKE :s OR b.accession_no LIKE :s OR b.shelf_location LIKE :s OR c.category_name LIKE :s)";
    $p[':s'] = "%$search%";
}
if ($category) { $sql .= " AND b.category_id = :c"; $p[':c'] = $category; }
if ($avail === 'available')   $sql .= " AND b.copies_available > 0";
if ($avail === 'unavailable') $sql .= " AND b.copies_available = 0";
$sql .= " ORDER BY b.title";
$st = $pdo->prepare($sql); $st->execute($p);
$books = $st->fetchAll();
$cats = $pdo->query("SELECT category_id, category_name FROM book_category ORDER BY category_name")->fetchAll();

$title = 'Catalog Search'; $active = 'catalog';
include 'includes/header.php';
?>
<section class="search-panel">
    <form method="GET" action="index.php" class="search-form">
        <div class="input-group main-search">
            <label for="search">Search Catalog</label>
            <input type="text" id="search" name="search" placeholder="Title, author, ISBN, accession no., shelf or category..." value="<?= e($search) ?>">
        </div>
        <div class="input-group">
            <label for="category">Category</label>
            <select id="category" name="category">
                <option value="0">All Categories</option>
                <?php foreach ($cats as $c): ?>
                    <option value="<?= $c['category_id'] ?>" <?= $category === (int)$c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="input-group">
            <label for="availability">Availability</label>
            <select id="availability" name="availability">
                <option value="">Any</option>
                <option value="available" <?= $avail === 'available' ? 'selected' : '' ?>>Copies available</option>
                <option value="unavailable" <?= $avail === 'unavailable' ? 'selected' : '' ?>>All copies out</option>
            </select>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="index.php" class="btn btn-secondary">Reset</a>
        </div>
    </form>
</section>

<section class="results-header">
    <h2>Catalog Results (<?= count($books) ?> <?= count($books) === 1 ? 'title' : 'titles' ?> found)</h2>
</section>

<section class="catalog-grid">
<?php if (!$books): ?>
    <div class="empty-state"><h3>No matching titles found</h3><p>Try different keywords or clear the filters.</p></div>
<?php else: foreach ($books as $b):
    $ok = $b['copies_available'] > 0; ?>
    <article class="book-card">
        <div class="card-header">
            <span class="badge category-badge"><?= e($b['category_name']) ?></span>
            <span class="badge status-badge <?= $ok ? 'status-available' : 'status-checked-out' ?>"><?= $ok ? 'Available' : 'All copies out' ?></span>
        </div>
        <h3 class="book-title"><?= e($b['title']) ?></h3>
        <p class="book-author">by <?= e($b['author']) ?></p>
        <ul class="book-meta">
            <li><strong>Accession:</strong> <?= e($b['accession_no']) ?></li>
            <li><strong>Shelf:</strong> <?= e($b['shelf_location'] ?: 'N/A') ?></li>
            <li><strong>Copies:</strong> <?= (int)$b['copies_available'] ?> of <?= (int)$b['copies_total'] ?> on shelf</li>
        </ul>
        <div class="card-footer">
            <button type="button" class="btn btn-outline view-details-btn" data-book="<?= e(json_encode($b)) ?>">
                <?= $ok ? 'View Details' : 'View Details &amp; Reserve' ?>
            </button>
        </div>
    </article>
<?php endforeach; endif; ?>
</section>

<div id="bookModal" class="modal" aria-hidden="true">
    <div class="modal-content">
        <button type="button" class="close-modal" id="closeModal">&times;</button>
        <div id="modalDetails"></div>
        <div id="reservationSection" class="reservation-box">
            <h4>Reserve this title</h4>
            <p style="font-size:.85rem;color:#64748b;margin-bottom:8px;">All copies are on loan. Enter your student number to join the waiting list.</p>
            <form id="reserveForm">
                <input type="hidden" id="reserveBookId" name="book_id">
                <div class="form-row">
                    <input type="text" name="student_no" placeholder="Student No. (e.g. 2024-00001)" required pattern="\d{4}-\d{5}">
                    <button type="submit" class="btn btn-primary">Confirm Reservation</button>
                </div>
            </form>
            <div id="reserveFeedback" class="feedback-msg"></div>
        </div>
    </div>
</div>
<script src="assets/js/app.js"></script>
<?php include 'includes/footer.php'; ?>
