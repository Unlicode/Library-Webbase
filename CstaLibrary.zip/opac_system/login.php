<?php
require_once 'includes/bootstrap.php';
if (current_user()) redirect('admin/index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || $password === '') {
        flash('err', 'Username and password are required.');
    } else {
        $s = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'A'");
        $s->execute([$username]);
        $row = $s->fetch();
        // First-run convenience: seeded accounts hold the placeholder 'UNSET' until their first login.
        if ($row && $row['password_hash'] === 'UNSET' && $password === 'Password1') {
            $row['password_hash'] = password_hash('Password1', PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?")->execute([$row['password_hash'], $row['user_id']]);
        }
        if ($row && password_verify($password, $row['password_hash']) && in_array($row['role'], ['Admin','Librarian','Staff'], true)) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['user_id' => (int)$row['user_id'], 'username' => $row['username'], 'role' => $row['role'], 'full_name' => $row['full_name']];
            redirect('admin/index.php');
        }
        flash('err', 'Invalid username or password.');
    }
    redirect('login.php');
}
$title = 'Staff Login'; $active = 'login';
include 'includes/header.php';
?>
<section class="admin-panel" style="max-width:420px;margin:40px auto;">
    <h2>Staff Login</h2>
    <form method="POST" class="admin-form">
        <?= csrf_field() ?>
        <div class="input-group"><label>Username</label><input type="text" name="username" required autofocus></div>
        <div class="input-group"><label>Password</label><input type="password" name="password" required></div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
