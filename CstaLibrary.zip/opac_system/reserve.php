<?php
// OPAC reservation endpoint (JSON). A student may reserve only titles with no copies on the shelf.
header('Content-Type: application/json');
require_once 'includes/bootstrap.php';

function out(bool $ok, string $msg): never { echo json_encode(['success' => $ok, 'message' => $msg]); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(false, 'Invalid request method.');

$bookId    = filter_input(INPUT_POST, 'book_id', FILTER_VALIDATE_INT);
$studentNo = trim($_POST['student_no'] ?? '');
if (!$bookId || !preg_match('/^\d{4}-\d{5}$/', $studentNo)) out(false, 'Enter a valid student number (format YYYY-NNNNN).');

try {
    $pdo->beginTransaction();

    $s = $pdo->prepare("SELECT student_id, status FROM student WHERE student_no = ?");
    $s->execute([$studentNo]);
    $stu = $s->fetch();
    if (!$stu || $stu['status'] !== 'A') { $pdo->rollBack(); out(false, 'No active student found with that student number.'); }

    $b = $pdo->prepare("SELECT copies_available, status FROM book WHERE book_id = ? FOR UPDATE");
    $b->execute([$bookId]);
    $book = $b->fetch();
    if (!$book || $book['status'] !== 'A') { $pdo->rollBack(); out(false, 'Title not found in the active collection.'); }
    if ($book['copies_available'] > 0) { $pdo->rollBack(); out(false, 'Copies are on the shelf. Please borrow it at the circulation desk.'); }

    $d = $pdo->prepare("SELECT 1 FROM reservation WHERE student_id=? AND book_id=? AND status IN ('P','A')");
    $d->execute([$stu['student_id'], $bookId]);
    if ($d->fetch()) { $pdo->rollBack(); out(false, 'You already have a pending reservation for this title.'); }

    $pdo->prepare("INSERT INTO reservation (student_id, book_id, request_date) VALUES (?, ?, CURDATE())")
        ->execute([$stu['student_id'], $bookId]);
    $pdo->commit();
    out(true, 'Reservation placed. You will be notified when a copy is returned.');
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    out(false, 'An error occurred while processing your reservation.');
}
