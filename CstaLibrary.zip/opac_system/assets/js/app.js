document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('bookModal');
    if (!modal) return;
    const details = document.getElementById('modalDetails');
    const resBox = document.getElementById('reservationSection');
    const form = document.getElementById('reserveForm');
    const bookId = document.getElementById('reserveBookId');
    const feedback = document.getElementById('reserveFeedback');

    const esc = s => { const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML; };

    document.querySelectorAll('.view-details-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const b = JSON.parse(btn.dataset.book);
            feedback.textContent = '';
            form.reset();
            details.innerHTML = `
                <span class="badge category-badge">${esc(b.category_name)}</span>
                <h3 style="margin-top:8px;font-size:1.35rem;">${esc(b.title)}</h3>
                <p style="color:#64748b;margin-bottom:12px;">by ${esc(b.author)}</p>
                <table class="modal-meta-table">
                    <tr><td>Copies on shelf</td><td><strong>${esc(b.copies_available)} of ${esc(b.copies_total)}</strong></td></tr>
                    <tr><td>Accession No.</td><td>${esc(b.accession_no)}</td></tr>
                    <tr><td>ISBN</td><td>${esc(b.isbn || 'N/A')}</td></tr>
                    <tr><td>Shelf Location</td><td>${esc(b.shelf_location || 'N/A')}</td></tr>
                    <tr><td>Publisher</td><td>${esc(b.publisher || 'N/A')} (${esc(b.publication_year)})</td></tr>
                    <tr><td>Waiting list</td><td>${esc(b.holds)} reservation(s)</td></tr>
                </table>`;
            if (Number(b.copies_available) === 0) { resBox.style.display = 'block'; bookId.value = b.book_id; }
            else resBox.style.display = 'none';
            modal.classList.add('open');
        });
    });

    document.getElementById('closeModal').addEventListener('click', () => modal.classList.remove('open'));
    modal.addEventListener('click', e => { if (e.target === modal) modal.classList.remove('open'); });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        feedback.style.color = '#1e3a8a';
        feedback.textContent = 'Processing reservation...';
        try {
            const r = await (await fetch('reserve.php', { method: 'POST', body: new FormData(form) })).json();
            feedback.style.color = r.success ? '#166534' : '#991b1b';
            feedback.textContent = r.message;
            if (r.success) setTimeout(() => location.reload(), 1500);
        } catch (err) {
            feedback.style.color = '#991b1b';
            feedback.textContent = 'Network error. Please try again.';
        }
    });
});
