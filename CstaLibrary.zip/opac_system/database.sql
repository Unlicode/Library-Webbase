-- Smart Library Management System with OPAC and Curriculum-to-Collection Alignment Analytics
-- Schema follows the ERD / data dictionary workbook (14 tables, MOD1-MOD14). Requires MySQL 8.0.16+.
CREATE DATABASE IF NOT EXISTS opac_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE opac_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS acquisition_recommendation, alignment_analytics, reservation, fine,
  borrow_transaction, curriculum_subject, subject, curriculum, program, book, book_category,
  faculty, student, users;
SET FOREIGN_KEY_CHECKS = 1;

-- MOD1 USERS
CREATE TABLE users (
  user_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(20)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(10)  NOT NULL,
  full_name     VARCHAR(80)  NOT NULL,
  status        CHAR(1)      NOT NULL DEFAULT 'A',
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_users_role   CHECK (role IN ('Admin','Librarian','Staff','Student','Faculty')),
  CONSTRAINT chk_users_status CHECK (status IN ('A','I'))
) ENGINE=InnoDB;

-- MOD6 PROGRAM
CREATE TABLE program (
  program_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  program_code VARCHAR(15)  NOT NULL UNIQUE,
  program_name VARCHAR(100) NOT NULL,
  department   VARCHAR(60)  NOT NULL,
  description  VARCHAR(200) NULL
) ENGINE=InnoDB;

-- MOD2 STUDENT
CREATE TABLE student (
  student_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL UNIQUE,
  student_no VARCHAR(15)  NOT NULL UNIQUE,
  last_name  VARCHAR(40)  NOT NULL,
  first_name VARCHAR(40)  NOT NULL,
  year_level TINYINT      NOT NULL,
  section    VARCHAR(10)  NOT NULL,
  program_id INT UNSIGNED NOT NULL,
  status     CHAR(1)      NOT NULL DEFAULT 'A',
  CONSTRAINT chk_student_year   CHECK (year_level BETWEEN 1 AND 4),
  CONSTRAINT chk_student_status CHECK (status IN ('A','I')),
  CONSTRAINT fk_student_user    FOREIGN KEY (user_id)    REFERENCES users(user_id)      ON DELETE CASCADE,
  CONSTRAINT fk_student_program FOREIGN KEY (program_id) REFERENCES program(program_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- MOD3 FACULTY
CREATE TABLE faculty (
  faculty_id  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  employee_no VARCHAR(15)  NOT NULL UNIQUE,
  last_name   VARCHAR(40)  NOT NULL,
  first_name  VARCHAR(40)  NOT NULL,
  department  VARCHAR(50)  NOT NULL,
  position    VARCHAR(30)  NULL,
  status      CHAR(1)      NOT NULL DEFAULT 'A',
  CONSTRAINT chk_faculty_status CHECK (status IN ('A','I')),
  CONSTRAINT fk_faculty_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- MOD5 BOOK_CATEGORY
CREATE TABLE book_category (
  category_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(60)  NOT NULL UNIQUE,
  description   VARCHAR(200) NULL
) ENGINE=InnoDB;

-- MOD4 BOOK
CREATE TABLE book (
  book_id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  accession_no     VARCHAR(15)  NOT NULL UNIQUE,
  title            VARCHAR(150) NOT NULL,
  author           VARCHAR(80)  NOT NULL,
  publisher        VARCHAR(80)  NULL,
  publication_year SMALLINT     NOT NULL,
  isbn             VARCHAR(20)  NULL UNIQUE,
  category_id      INT UNSIGNED NOT NULL,
  copies_total     SMALLINT     NOT NULL DEFAULT 1,
  copies_available SMALLINT     NOT NULL DEFAULT 1,
  shelf_location   VARCHAR(20)  NULL,
  status           CHAR(1)      NOT NULL DEFAULT 'A',
  CONSTRAINT chk_book_year   CHECK (publication_year >= 1900),
  CONSTRAINT chk_book_copies CHECK (copies_total >= 1 AND copies_available >= 0 AND copies_available <= copies_total),
  CONSTRAINT chk_book_status CHECK (status IN ('A','W')),
  CONSTRAINT fk_book_category FOREIGN KEY (category_id) REFERENCES book_category(category_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- MOD7 CURRICULUM
CREATE TABLE curriculum (
  curriculum_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  program_id    INT UNSIGNED NOT NULL,
  effective_sy  VARCHAR(9)   NOT NULL,
  description   VARCHAR(200) NULL,
  approved_by   VARCHAR(80)  NULL,
  status        CHAR(1)      NOT NULL DEFAULT 'A',
  CONSTRAINT chk_curr_status CHECK (status IN ('A','I')),
  CONSTRAINT fk_curr_program FOREIGN KEY (program_id) REFERENCES program(program_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- MOD8 SUBJECT
CREATE TABLE subject (
  subject_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  subject_code      VARCHAR(15)  NOT NULL UNIQUE,
  descriptive_title VARCHAR(100) NOT NULL,
  units             TINYINT      NOT NULL,
  description       VARCHAR(200) NULL,
  CONSTRAINT chk_subject_units CHECK (units BETWEEN 1 AND 6)
) ENGINE=InnoDB;

-- MOD9 CURRICULUM_SUBJECT
CREATE TABLE curriculum_subject (
  curriculum_subject_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  curriculum_id INT UNSIGNED NOT NULL,
  subject_id    INT UNSIGNED NOT NULL,
  year_level    TINYINT      NOT NULL,
  semester      VARCHAR(10)  NOT NULL,
  CONSTRAINT chk_cs_year CHECK (year_level BETWEEN 1 AND 4),
  CONSTRAINT chk_cs_sem  CHECK (semester IN ('1st','2nd','Summer')),
  CONSTRAINT uq_cs UNIQUE (curriculum_id, subject_id, semester),
  CONSTRAINT fk_cs_curriculum FOREIGN KEY (curriculum_id) REFERENCES curriculum(curriculum_id) ON DELETE CASCADE,
  CONSTRAINT fk_cs_subject    FOREIGN KEY (subject_id)    REFERENCES subject(subject_id)       ON DELETE RESTRICT
) ENGINE=InnoDB;

-- MOD10 BORROW_TRANSACTION
CREATE TABLE borrow_transaction (
  transaction_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id     INT UNSIGNED NOT NULL,
  book_id        INT UNSIGNED NOT NULL,
  borrow_date    DATE         NOT NULL,
  due_date       DATE         NOT NULL,
  return_date    DATE         NULL,
  status         VARCHAR(10)  NOT NULL DEFAULT 'B',
  processed_by   INT UNSIGNED NOT NULL,
  fine_amount    DECIMAL(5,2) NULL DEFAULT 0.00,
  CONSTRAINT chk_bt_status CHECK (status IN ('B','R','O')),
  CONSTRAINT chk_bt_dates  CHECK (due_date > borrow_date AND (return_date IS NULL OR return_date >= borrow_date)),
  CONSTRAINT chk_bt_fine   CHECK (fine_amount IS NULL OR fine_amount >= 0),
  CONSTRAINT fk_bt_student FOREIGN KEY (student_id)   REFERENCES student(student_id) ON DELETE RESTRICT,
  CONSTRAINT fk_bt_book    FOREIGN KEY (book_id)      REFERENCES book(book_id)       ON DELETE RESTRICT,
  CONSTRAINT fk_bt_user    FOREIGN KEY (processed_by) REFERENCES users(user_id)      ON DELETE RESTRICT
) ENGINE=InnoDB;

-- MOD11 FINE
CREATE TABLE fine (
  fine_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  transaction_id INT UNSIGNED NOT NULL UNIQUE,
  amount         DECIMAL(5,2) NOT NULL,
  status         CHAR(1)      NOT NULL DEFAULT 'U',
  date_paid      DATE         NULL,
  or_number      VARCHAR(20)  NULL,
  CONSTRAINT chk_fine_amount CHECK (amount > 0),
  CONSTRAINT chk_fine_status CHECK (status IN ('U','P')),
  CONSTRAINT chk_fine_paid   CHECK (status = 'U' OR (date_paid IS NOT NULL AND or_number IS NOT NULL)),
  CONSTRAINT fk_fine_tx FOREIGN KEY (transaction_id) REFERENCES borrow_transaction(transaction_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- MOD12 RESERVATION
CREATE TABLE reservation (
  reservation_id  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id      INT UNSIGNED NOT NULL,
  book_id         INT UNSIGNED NOT NULL,
  request_date    DATE         NOT NULL,
  status          VARCHAR(10)  NOT NULL DEFAULT 'P',
  pickup_deadline DATE         NULL,
  notified        CHAR(1)      NOT NULL DEFAULT 'N',
  CONSTRAINT chk_res_status   CHECK (status IN ('P','A','C')),
  CONSTRAINT chk_res_notified CHECK (notified IN ('Y','N')),
  CONSTRAINT fk_res_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
  CONSTRAINT fk_res_book    FOREIGN KEY (book_id)    REFERENCES book(book_id)       ON DELETE CASCADE
) ENGINE=InnoDB;

-- MOD13 ALIGNMENT_ANALYTICS
CREATE TABLE alignment_analytics (
  record_id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  curriculum_subject_id INT UNSIGNED  NOT NULL,
  book_id               INT UNSIGNED  NOT NULL,
  relevance_score       DECIMAL(3,2)  NOT NULL DEFAULT 0.00,
  titles_available      SMALLINT      NOT NULL,
  coverage_status       VARCHAR(15)   NOT NULL,
  remarks               VARCHAR(200)  NULL,
  generated_date        DATE          NOT NULL,
  CONSTRAINT chk_aa_score    CHECK (relevance_score BETWEEN 0 AND 1),
  CONSTRAINT chk_aa_titles   CHECK (titles_available >= 0),
  CONSTRAINT chk_aa_coverage CHECK (coverage_status IN ('Aligned','Partial','None')),
  CONSTRAINT uq_aa UNIQUE (curriculum_subject_id, book_id, generated_date),
  CONSTRAINT fk_aa_cs   FOREIGN KEY (curriculum_subject_id) REFERENCES curriculum_subject(curriculum_subject_id) ON DELETE CASCADE,
  CONSTRAINT fk_aa_book FOREIGN KEY (book_id)               REFERENCES book(book_id)                             ON DELETE CASCADE
) ENGINE=InnoDB;

-- MOD14 ACQUISITION_RECOMMENDATION
CREATE TABLE acquisition_recommendation (
  recommendation_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  curriculum_subject_id INT UNSIGNED NOT NULL,
  recommended_title     VARCHAR(150) NOT NULL,
  justification         VARCHAR(250) NOT NULL,
  priority              VARCHAR(8)   NOT NULL DEFAULT 'Medium',
  status                VARCHAR(10)  NOT NULL DEFAULT 'Open',
  date_generated        DATE         NOT NULL,
  CONSTRAINT chk_ar_priority CHECK (priority IN ('High','Medium','Low')),
  CONSTRAINT chk_ar_status   CHECK (status IN ('Open','Ordered','Done')),
  CONSTRAINT fk_ar_cs FOREIGN KEY (curriculum_subject_id) REFERENCES curriculum_subject(curriculum_subject_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Sample data. Passwords are set by setup.php (default: Password1)
-- ---------------------------------------------------------------
INSERT INTO users (username, password_hash, role, full_name) VALUES
('admin',      'UNSET', 'Admin',     'System Administrator'),
('librarian',  'UNSET', 'Librarian', 'Head Librarian'),
('staff01',    'UNSET', 'Staff',     'Circulation Staff'),
('2024-00001', 'UNSET', 'Student',   'Juan Dela Cruz'),
('2024-00002', 'UNSET', 'Student',   'Maria Santos'),
('EMP-0001',   'UNSET', 'Faculty',   'Ana Reyes');

INSERT INTO program (program_code, program_name, department, description) VALUES
('BSIT','Bachelor of Science in Information Technology','College of Computing','Computing and software program'),
('BSED-ENG','Bachelor of Secondary Education major in English','College of Education','English teacher education');

INSERT INTO student (user_id, student_no, last_name, first_name, year_level, section, program_id) VALUES
(4,'2024-00001','Dela Cruz','Juan',3,'BSIT 3-4',1),
(5,'2024-00002','Santos','Maria',2,'BSED 2-1',2);

INSERT INTO faculty (user_id, employee_no, last_name, first_name, department, position) VALUES
(6,'EMP-0001','Reyes','Ana','College of Computing','Instructor');

INSERT INTO book_category (category_name, description) VALUES
('Computer Science','Programming, algorithms and software engineering'),
('Literature','Novels, poetry and literary criticism'),
('History','World and local history'),
('Information Systems','Databases and information management');

INSERT INTO book (accession_no, title, author, publisher, publication_year, isbn, category_id, copies_total, copies_available, shelf_location) VALUES
('ACC-0001','Clean Code: A Handbook of Agile Software Craftsmanship','Robert C. Martin','Prentice Hall',2008,'9780132350884',1,3,3,'QA76.76 A1'),
('ACC-0002','Introduction to Algorithms','Thomas H. Cormen','MIT Press',2009,'9780262033848',1,2,0,'QA76.6 A2'),
('ACC-0003','Database System Concepts','Abraham Silberschatz','McGraw-Hill',2019,'9780078022159',4,4,4,'QA76.9 D1'),
('ACC-0004','To Kill a Mockingbird','Harper Lee','Harper Perennial',2006,'9780061120084',2,2,2,'PS3562 L4'),
('ACC-0005','Sapiens: A Brief History of Humankind','Yuval Noah Harari','Harper',2015,'9780307277671',3,1,1,'CB113 H1'),
('ACC-0006','Domain-Driven Design','Eric Evans','Addison-Wesley',2003,'9780321125217',1,1,1,'QA76.76 A3');

INSERT INTO curriculum (program_id, effective_sy, description, approved_by) VALUES
(1,'2024-2025','BSIT revised curriculum','Academic Council'),
(2,'2024-2025','BSED English curriculum','Academic Council');

INSERT INTO subject (subject_code, descriptive_title, units, description) VALUES
('IT101','Introduction to Programming',3,'Programming fundamentals and algorithms'),
('IT201','Database Management Systems',3,'Relational database design and SQL'),
('IT301','Software Engineering',3,'Clean code, design and agile software development'),
('IT302','Network Security',3,'Cybersecurity and network protection'),
('EN101','Philippine and World Literature',3,'Novels and literary studies');

INSERT INTO curriculum_subject (curriculum_id, subject_id, year_level, semester) VALUES
(1,1,1,'1st'),(1,2,2,'2nd'),(1,3,3,'1st'),(1,4,3,'2nd'),(2,5,2,'1st');

-- two copies of ACC-0002 currently on loan (matches copies_available = 0)
INSERT INTO borrow_transaction (student_id, book_id, borrow_date, due_date, status, processed_by) VALUES
(1,2,DATE_SUB(CURDATE(), INTERVAL 2 DAY),DATE_ADD(CURDATE(), INTERVAL 1 DAY),'B',2),
(2,2,DATE_SUB(CURDATE(), INTERVAL 1 DAY),DATE_ADD(CURDATE(), INTERVAL 2 DAY),'B',2);
